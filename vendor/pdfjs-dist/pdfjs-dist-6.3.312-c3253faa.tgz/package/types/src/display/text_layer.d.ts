export type PageViewport = import("./page_viewport").PageViewport;
export type TextContent = import("./api").TextContent;
export type TextLayerImages = import("./text_layer_images").TextLayerImages;
export type TextLayerParameters = {
    /**
     * - Text content to
     * render, i.e. the value returned by the page's `streamTextContent` or
     * `getTextContent` method.
     */
    textContentSource: ReadableStream | TextContent;
    /**
     * - The DOM node that will contain the text
     * runs.
     */
    container: HTMLElement;
    /**
     * - The target viewport to properly layout
     * the text runs.
     */
    viewport: PageViewport;
    /**
     * - An optional TextLayerImages instance
     * that handles right clicking on images.
     */
    images?: import("./text_layer_images").TextLayerImages | undefined;
};
export type TextLayerUpdateParameters = {
    /**
     * - The target viewport to properly layout
     * the text runs.
     */
    viewport: PageViewport;
    /**
     * - Callback invoked before the textLayer is
     * updated in the DOM.
     */
    onBefore?: Function | undefined;
};
export class TextLayer {
    static #ascentCache: Map<any, any>;
    static #canvasContexts: Map<any, any>;
    static #canvasCtxFonts: WeakMap<object, any>;
    static #minFontSize: null;
    static #pendingTextLayers: Set<any>;
    static get fontFamilyMap(): any;
    /**
     * Clean-up global textLayer data.
     * @returns {undefined}
     */
    static cleanup(): undefined;
    static #getCtx(lang?: null): any;
    static #ensureCtxFont(ctx: any, size: any, family: any): void;
    /**
     * Compute the minimum font size enforced by the browser.
     */
    static #ensureMinFontSizeComputed(): void;
    static #getAscent(fontFamily: any, style: any, lang: any): any;
    /**
     * @param {TextLayerParameters} options
     */
    constructor({ textContentSource, images, container, viewport }: TextLayerParameters);
    /**
     * Render the textLayer.
     * @returns {Promise}
     */
    render(): Promise<any>;
    /**
     * Update a previously rendered textLayer, if necessary.
     * @param {TextLayerUpdateParameters} options
     * @returns {undefined}
     */
    update({ viewport, onBefore }: TextLayerUpdateParameters): undefined;
    /**
     * Cancel rendering of the textLayer.
     * @returns {undefined}
     */
    cancel(): undefined;
    /**
     * @type {Array<HTMLElement>} HTML elements that correspond to the text items
     *   of the textContent input.
     *   This is output and will initially be set to an empty array.
     */
    get textDivs(): Array<HTMLElement>;
    /**
     * @type {Array<string>} Strings that correspond to the `str` property of
     *   the text items of the textContent input.
     *   This is output and will initially be set to an empty array
     */
    get textContentItemsStr(): Array<string>;
    #private;
}
